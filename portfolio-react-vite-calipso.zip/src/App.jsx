import React, { useEffect, useState } from 'react'

const Pill = ({ children }) => <span className="badge">{children}</span>

function Section ({ id, title, subtitle, children }) {
  return (
    <section id={id} className="scroll-mt-24">
      <div className="container">
        <h2>{title}</h2>
        {subtitle && <p className="subtitle">{subtitle}</p>}
        {children}
      </div>
    </section>
  )
}

function useTheme () {
  const [dark, setDark] = useState(false)
  useEffect(() => {
    const saved = localStorage.getItem('prefers-dark') === 'true'
    setDark(saved)
  }, [])
  useEffect(() => {
    document.documentElement.classList.toggle('dark', dark)
    localStorage.setItem('prefers-dark', String(dark))
  }, [dark])
  return { dark, setDark }
}

export default function App () {
  const { dark, setDark } = useTheme()
  const role = "Estudiante de Ingeniería Informática"
  const summary = "Portafolio final del curso: integración de aprendizajes, proyectos y plan de desarrollo profesional, potenciado con IA."
  const intro = `La construcción de un portafolio profesional personalizado con apoyo de inteligencia artificial (IA) es una estrategia para enfrentar un mercado laboral en transformación. Este sitio integra los aprendizajes del curso: análisis de vacantes, creación de un bot de empleabilidad, redacción de un correo profesional y diseño de un mapa personal de herramientas de IA. El objetivo es sistematizar competencias técnicas, blandas y digitales, experiencias aplicadas y un plan de desarrollo con una visión ética del uso de la IA.`
  const presentacion = `Soy estudiante de segundo año de Ingeniería Informática con interés en desarrollo de software, IA aplicada y soluciones tecnológicas para empresas. Me caracterizo por el aprendizaje continuo, la curiosidad y el compromiso por crear proyectos con impacto.`

  const skills = {
    tecnicas: ["Java","PHP","JavaScript","HTML & CSS","MySQL","MongoDB","Cassandra","Servicios SOAP & REST","UML","ERD","Android Studio"],
    blandas: ["Comunicación efectiva","Trabajo en equipo","Adaptabilidad","Liderazgo y organización"],
    digitales: ["IA generativa (ChatGPT, Notion AI, Copilot)","Canva","Notion","Trello","Power BI (en progreso)"]
  }

  const projects = [
    {
      title: "MIPROYECTO – E‑commerce académico",
      desc: "Sitio web de comercio electrónico para una empresa ficticia de computación. Stack: PHP, HTML, CSS y JS. Enfoque en estructura y buenas prácticas.",
      tags: ["Web","PHP","JS","UX"]
    },
    {
      title: "Servicios SOAP – Conversión de temperaturas",
      desc: "Implementación de servicios web en Java con WSDL y pruebas desde cliente HTML/JS. Documentación técnica y pruebas unitarias.",
      tags: ["Java","SOAP","WSDL"]
    },
    {
      title: "Mini API REST – Conversión CLP/USD",
      desc: "Prototipo REST con integración de cliente Java Swing para conversión bidireccional. Validaciones y manejo de errores.",
      tags: ["REST","Java","Swing"]
    },
    {
      title: "NoSQL – Modelado Cassandra y MongoDB",
      desc: "Modelos académicos: inscripción de asignaturas (Cassandra) y veterinaria (MongoDB). Diseño de esquemas y consultas.",
      tags: ["Cassandra","MongoDB"]
    },
    {
      title: "App móvil de clima",
      desc: "Aplicación Android Studio con consumo de APIs y diseño responsivo. Enfoque en arquitectura limpia.",
      tags: ["Android","APIs"]
    },
    {
      title: "IA en productividad académica",
      desc: "Uso de IA generativa para correos profesionales, mapas conceptuales y planificación estratégica. Énfasis en revisión y ética.",
      tags: ["IA","Productividad"]
    }
  ]

  const plan = [
    {
      when: "0–3 meses",
      title: "Base sólida y visibilidad",
      points: [
        "Completar curso de Power BI y análisis de datos.",
        "Publicar este portafolio en línea (Netlify / GitHub Pages).",
        "Actualizar CV digital y LinkedIn con proyectos del curso."
      ]
    },
    {
      when: "3–6 meses",
      title: "Especialización y proyecto con IA",
      points: [
        "Curso introductorio de Machine Learning / Data Science.",
        "Desarrollar un proyecto personal que integre IA en web o móvil.",
        "Participar en un hackatón o meetup técnico."
      ]
    },
    {
      when: "6–12 meses",
      title: "Consolidación profesional",
      points: [
        "Profundizar en backend y bases de datos.",
        "Explorar prácticas profesionales en empresas tecnológicas.",
        "Iterar el portafolio con nuevos logros y reflexiones."
      ]
    }
  ]

  return (
    <div>
      <header className="nav">
        <div className="container nav-row">
          <a href="#inicio" className="logo" style={{fontWeight:700}}>Portafolio IA</a>
          <nav className="nav" aria-label="Navegación principal">
            <a href="#presentacion">Presentación</a>
            <a href="#habilidades">Habilidades</a>
            <a href="#proyectos">Proyectos</a>
            <a href="#plan">Plan</a>
            <a href="#reflexion">Reflexión</a>
            <a href="#contacto">Contacto</a>
          </nav>
          <button className="switch" onClick={() => setDark(d => !d)} title="Cambiar tema">
            {dark ? "☀️" : "🌙"}
          </button>
        </div>
      </header>

      <main>
        <section id="inicio" className="hero">
          <div className="container grid grid-2">
            <div>
              <h1>Estudiante de <span className="accent">Ingeniería Informática</span></h1>
              <p>{summary}</p>
              <div style={{display:'flex',gap:8,flexWrap:'wrap',margin:'12px 0 20px'}}>
                <span className="chip">IA responsable</span>
                <span className="chip">Aprendizaje continuo</span>
                <span className="chip">Proyectos aplicados</span>
              </div>
              <div style={{display:'flex',gap:10,flexWrap:'wrap'}}>
                <a className="btn btn-primary" href="#proyectos">Ver proyectos</a>
                <a className="btn" href="#plan">Plan de desarrollo</a>
              </div>
            </div>
            <div className="card shadow">
              <h3 style={{margin:0}}>Introducción</h3>
              <p className="muted" style={{marginTop:8,lineHeight:1.7}}>{intro}</p>
            </div>
          </div>
        </section>

        <Section id="presentacion" title="Presentación personal" subtitle="Quién soy, qué hago e intereses profesionales">
          <div className="grid grid-2" style={{alignItems:'start'}}>
            <div className="card shadow">
              <p style={{lineHeight:1.8}}>{presentacion}</p>
            </div>
            <aside className="grid" style={{gap:14}}>
              <div className="card"><p className="muted">Disponible para prácticas / proyectos freelance</p></div>
              <div className="card">
                <p><strong>Ubicación:</strong> Antofagasta, Chile</p>
                <p><strong>Email:</strong> ariel.c.pizarro@dataimagenes.cl</p>
                <p><strong>LinkedIn:</strong> <a href="https://www.linkedin.com/in/arielcontreraspizarro/" target="_blank" rel="noreferrer">arielcontreraspizarro</a></p>
              </div>
            </aside>
          </div>
        </Section>

        <Section id="habilidades" title="Habilidades actuales" subtitle="Técnicas, blandas y digitales">
          <div className="grid grid-3">
            <div className="card shadow">
              <h3 style={{marginTop:0}}>Técnicas</h3>
              <div style={{display:'flex',gap:8,flexWrap:'wrap'}}>
                {skills.tecnicas.map((s,i)=>(<span key={i} className="badge">{s}</span>))}
              </div>
            </div>
            <div className="card shadow">
              <h3 style={{marginTop:0}}>Blandas</h3>
              <div style={{display:'flex',gap:8,flexWrap:'wrap'}}>
                {skills.blandas.map((s,i)=>(<span key={i} className="badge">{s}</span>))}
              </div>
            </div>
            <div className="card shadow">
              <h3 style={{marginTop:0}}>Digitales</h3>
              <div style={{display:'flex',gap:8,flexWrap:'wrap'}}>
                {skills.digitales.map((s,i)=>(<span key={i} className="badge">{s}</span>))}
              </div>
            </div>
          </div>
        </Section>

        <Section id="proyectos" title="Proyectos y experiencias aplicadas" subtitle="Con foco en el uso de IA y aprendizajes del curso">
          <div className="grid grid-2">
            {projects.map((p,i)=>(
              <article key={i} className="card shadow">
                <div style={{display:'flex',justifyContent:'space-between',gap:12,alignItems:'center'}}>
                  <h3 style={{margin:0}}>{p.title}</h3>
                </div>
                <p className="muted" style={{lineHeight:1.7}}>{p.desc}</p>
                <div style={{display:'flex',gap:8,flexWrap:'wrap',marginTop:8}}>
                  {p.tags.map((t,j)=>(<span key={j} className="badge">{t}</span>))}
                </div>
              </article>
            ))}
          </div>
        </Section>

        <Section id="plan" title="Plan de desarrollo profesional" subtitle="Hoja de ruta con próximos pasos y objetivos">
          <div className="card shadow tl">
            {plan.map((t,i)=>(
              <div key={i} className="tl-item">
                <span className="dot"></span>
                <p className="muted" style={{margin:0}}>{t.when}</p>
                <h3 style={{margin:'6px 0'}}>{t.title}</h3>
                <ul>
                  {t.points.map((p,k)=>(<li key={k}>{p}</li>))}
                </ul>
              </div>
            ))}
          </div>
        </Section>

        <Section id="reflexion" title="Reflexión final" subtitle="Qué cambió en mi forma de pensar el trabajo y la tecnología">
          <div className="card shadow">
            <p style={{lineHeight:1.8}}>
              Este portafolio mostró que la IA es un aliado estratégico para potenciar creatividad, productividad y toma de decisiones. Lo concibo como un recurso vivo que debo actualizar periódicamente, reforzando reskilling y upskilling, ética digital y uso responsable de datos para desarrollarme como profesional competente y consciente.
            </p>
          </div>
        </Section>

        <Section id="contacto" title="Contacto" subtitle="¿Conversamos?">
          <div className="grid grid-2">
            <div className="card shadow">
              <form action="https://formspree.io/f/your-id" method="POST">
                <div style={{display:'grid',gap:12}}>
                  <div>
                    <label>Nombre</label>
                    <input name="name" placeholder="Tu nombre" required />
                  </div>
                  <div>
                    <label>Email</label>
                    <input type="email" name="email" placeholder="tu-email@ejemplo.com" required />
                  </div>
                  <div>
                    <label>Mensaje</label>
                    <textarea name="message" rows="4" placeholder="Cuéntame sobre tu proyecto o consulta" required></textarea>
                  </div>
                  <button className="btn btn-primary" type="submit">Enviar</button>
                  <p className="muted" style={{fontSize:'.85rem'}}>Este formulario usa Formspree. Reemplaza <code>your-id</code> por tu ID real.</p>
                </div>
              </form>
            </div>
            <div className="card shadow">
              <h3 style={{marginTop:0}}>Datos de contacto</h3>
              <ul style={{listStyle:'none',padding:0,margin:'10px 0 0',lineHeight:1.9}}>
                <li>📍 Antofagasta, Chile</li>
                <li>✉️ ariel.c.pizarro@dataimagenes.cl</li>
                <li>🔗 LinkedIn: <a href="https://www.linkedin.com/in/arielcontreraspizarro/" target="_blank" rel="noreferrer">arielcontreraspizarro</a></li>
                <li>🌐 Este sitio</li>
              </ul>
              <div style={{display:'flex',gap:8,flexWrap:'wrap',marginTop:12}}>
                <span className="badge">Disponible para prácticas</span>
                <span className="badge">Proyectos freelance</span>
              </div>
            </div>
          </div>
        </Section>
      </main>

      <footer>
        <div className="container">
          © {new Date().getFullYear()} Portafolio Profesional con IA — Calipso oscuro & blanco
        </div>
      </footer>
    </div>
  )
}
